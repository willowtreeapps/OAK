
oak-demos*.apk
    -A sample application using OAK

/libs
    -Copy its contents to your android libs directory
